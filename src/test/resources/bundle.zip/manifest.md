Support Bundle Manifest
=======================

Generated on 2017-09-07 00:52:08.880+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-09-07_00.52.00.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Slave Log Recorders

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

  * About browser

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/hour.png`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/min.png`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/master/sec10.png`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/hour.png`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/min.png`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/no-label/sec10.png`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/hour.png`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/min.png`

      - `load-stats/overall/sec10.csv`

      - `load-stats/overall/sec10.png`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

