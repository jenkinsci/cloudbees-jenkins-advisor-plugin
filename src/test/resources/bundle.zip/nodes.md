Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/home/evildethow/workspace/support/cloudbees-advisor-plugin/work`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_144
          + Maximum memory:   6.95 GB (7464288256)
          + Allocated memory: 1.35 GB (1453850624)
          + Free memory:      1.29 GB (1387632232)
          + In-use memory:    63.15 MB (66218392)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.144-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.8.0-53-generic
          + Distribution: Linux Mint 18.2 Sonya
      - Process ID: 28027 (0x6d7b)
      - Process started: 2017-09-07 00:51:49.651+0000
      - Process uptime: 19 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `/home/evildethow/intellij/idea-IC-172.3968.16/plugins/maven/lib/maven3/boot/plexus-classworlds-2.5.2.jar:/home/evildethow/intellij/idea-IC-172.3968.16/lib/idea_rt.jar`
          + Library path: `/home/evildethow/intellij/idea-IC-172.3968.16/bin::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-agentlib:jdwp=transport=dt_socket,address=127.0.0.1:39973,suspend=y,server=n`
          + arg[1]: `-Dmaven.multiModuleProjectDirectory=/home/evildethow/workspace/support/cloudbees-advisor-plugin`
          + arg[2]: `-Dmaven.home=/home/evildethow/intellij/idea-IC-172.3968.16/plugins/maven/lib/maven3`
          + arg[3]: `-Dclassworlds.conf=/home/evildethow/intellij/idea-IC-172.3968.16/plugins/maven/lib/maven3/bin/m2.conf`
          + arg[4]: `-Dfile.encoding=UTF-8`

