Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 404.433GB left on /home/evildethow/workspace/support/cloudbees-advisor-plugin/work.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:17235/32026MB  Swap:32619/32619MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 404.433GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
