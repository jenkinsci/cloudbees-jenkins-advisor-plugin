Monitors
========

`com.cloudbees.jenkins.plugins.advisor.Reminder`
--------------
(active and enabled)

`jenkins.CLI`
--------------
(active and enabled)

`jenkins.diagnostics.SecurityIsOffMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
